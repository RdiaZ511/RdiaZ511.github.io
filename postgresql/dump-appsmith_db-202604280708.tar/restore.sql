--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.8 (Debian 15.8-1.pgdg110+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE appsmith_db;
--
-- Name: appsmith_db; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE appsmith_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE appsmith_db OWNER TO admin;

\unrestrict (null)
\connect appsmith_db
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: appsmith_db; Type: DATABASE PROPERTIES; Schema: -; Owner: admin
--

ALTER DATABASE appsmith_db SET search_path TO '$user', 'public', 'topology';


\unrestrict (null)
\connect appsmith_db
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO admin;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: admin
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_raster; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_raster WITH SCHEMA public;


--
-- Name: EXTENSION postgis_raster; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_raster IS 'PostGIS raster types and functions';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alcaldiainfraestructura; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.alcaldiainfraestructura (
    id integer NOT NULL,
    alcaldia character(14) NOT NULL,
    fechaingreso date DEFAULT CURRENT_DATE NOT NULL,
    areadato character varying(2) NOT NULL,
    gestionpor character(2) NOT NULL,
    clasedato character varying(1) NOT NULL,
    datoespecifico text NOT NULL,
    tipovalordato character(2) NOT NULL,
    valordato text NOT NULL,
    parroquia character(20),
    indice character varying(4)
);
ALTER TABLE ONLY public.alcaldiainfraestructura ALTER COLUMN indice SET STORAGE PLAIN;


ALTER TABLE public.alcaldiainfraestructura OWNER TO admin;

--
-- Name: alcaldiainfraestructura_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.alcaldiainfraestructura ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.alcaldiainfraestructura_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dic_rubros; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.dic_rubros (
    codigo character(3) NOT NULL,
    tipo character(1) NOT NULL,
    categoria character varying(60) NOT NULL,
    descripcion character varying(200),
    activo smallint DEFAULT 1 NOT NULL,
    CONSTRAINT ck_dr_activo CHECK ((activo = ANY (ARRAY[0, 1]))),
    CONSTRAINT ck_dr_tipo CHECK ((tipo = ANY (ARRAY['P'::bpchar, 'I'::bpchar])))
);


ALTER TABLE public.dic_rubros OWNER TO admin;

--
-- Name: TABLE dic_rubros; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON TABLE public.dic_rubros IS 'Diccionario de categorías de productos e insumos';


--
-- Name: COLUMN dic_rubros.codigo; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.dic_rubros.codigo IS 'Código único: P01-P50 Productos, I01-I40 Insumos';


--
-- Name: COLUMN dic_rubros.tipo; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.dic_rubros.tipo IS 'P = Producto  |  I = Insumo';


--
-- Name: COLUMN dic_rubros.categoria; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.dic_rubros.categoria IS 'Nombre de la categoría';


--
-- Name: COLUMN dic_rubros.descripcion; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.dic_rubros.descripcion IS 'Ejemplos orientativos del contenido';


--
-- Name: COLUMN dic_rubros.activo; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.dic_rubros.activo IS '1 = Activo  |  0 = Inactivo';


--
-- Name: entidad; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.entidad (
    codigo integer NOT NULL,
    entidad character varying(180),
    identificacion character varying(14),
    municipio_parroquia character varying(4),
    direccion character varying(180),
    ubicacion character varying(200),
    fecha_inicio date,
    telefono character varying(180),
    tipo_entidad character varying(1),
    tamano_entidad smallint,
    contacto character varying(60),
    telefono_contacto character varying(180),
    web_entidad character varying(50),
    instagram_entidad character varying(50),
    twitter_entidad character varying(50),
    facebook_entidad character varying(50),
    capital_humano integer,
    productos character varying(400),
    capacidad_produccion character varying(320),
    instalada character varying(200),
    operativa smallint,
    participacion_mercado smallint,
    materia_prima character varying(300),
    sector character varying(1),
    estado character varying(50),
    municipio character varying(50),
    parroquia character varying(50)
);


ALTER TABLE public.entidad OWNER TO admin;

--
-- Name: TABLE entidad; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON TABLE public.entidad IS '0101=Bejuma, Bejuma
0102=Bejuma, Canoabo
0103=Bejuma, Simón Bolívar
0201=Carlos Arvelo, Belén
0202=Carlos Arvelo, Güigüe
0203=Carlos Arvelo, Tacarigua
0301=Diego Ibarra, Aguas Calientes
0302=Diego Ibarra, Mariara
0401=Guacara, Ciudad Alianza
0402=Guacara, Guacara
0403=Guacara, Yagua
0501=Juan José Mora, Moron
0502=Juan José Mora, Urama
0601=Libertador, Independencia
0602=Libertador, Tocuyito
0701=Los Guayos, Los Guayos
0801=Miranda, Miranda
0901=Montalbán, Montalbán
1001=Naguanagua, Naguanagua
1101=Puerto Cabello, Bartolomé Salom
1102=Puerto Cabello, Borburata
1103=Puerto Cabello, Democracia
1104=Puerto Cabello, Fraternidad
1105=Puerto Cabello, Goaigoaza
1106=Puerto Cabello, Juan José Flores
1107=Puerto Cabello, Patanemo
1108=Puerto Cabello, Unión
1201=San Diego, San Diego
1301=San Joaquín, San Joaquín
1401=Valencia, Candelaria
1402=Valencia, Catedral
1403=Valencia, El Socorro
1404=Valencia, Miguel Peña
1405=Valencia, Negro Primero
1406=Valencia, Rafael Urdaneta
1407=Valencia, San Blas
1408=Valencia, San José
1409=Valencia, Santa Rosa';


--
-- Name: COLUMN entidad.municipio_parroquia; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.entidad.municipio_parroquia IS '0101=Bejuma, Bejuma
0102=Bejuma, Canoabo
0103=Bejuma, Simón Bolívar
0201=Carlos Arvelo, Belén
0202=Carlos Arvelo, Güigüe
0203=Carlos Arvelo, Tacarigua
0301=Diego Ibarra, Aguas Calientes
0302=Diego Ibarra, Mariara
0401=Guacara, Ciudad Alianza
0402=Guacara, Guacara
0403=Guacara, Yagua
0501=Juan José Mora, Moron
0502=Juan José Mora, Urama
0601=Libertador, Independencia
0602=Libertador, Tocuyito
0701=Los Guayos, Los Guayos
0801=Miranda, Miranda
0901=Montalbán, Montalbán
1001=Naguanagua, Naguanagua
1101=Puerto Cabello, Bartolomé Salom
1102=Puerto Cabello, Borburata
1103=Puerto Cabello, Democracia
1104=Puerto Cabello, Fraternidad
1105=Puerto Cabello, Goaigoaza
1106=Puerto Cabello, Juan José Flores
1107=Puerto Cabello, Patanemo
1108=Puerto Cabello, Unión
1201=San Diego, San Diego
1301=San Joaquín, San Joaquín
1401=Valencia, Candelaria
1402=Valencia, Catedral
1403=Valencia, El Socorro
1404=Valencia, Miguel Peña
1405=Valencia, Negro Primero
1406=Valencia, Rafael Urdaneta
1407=Valencia, San Blas
1408=Valencia, San José
1409=Valencia, Santa Rosa';


--
-- Name: entidad_codigo_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.entidad ALTER COLUMN codigo ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.entidad_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: entidad_rubros; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.entidad_rubros (
    id integer NOT NULL,
    codigo_entidad integer NOT NULL,
    codigo_rubro character(3) NOT NULL,
    tipo character(1) NOT NULL,
    observacion character varying(100),
    CONSTRAINT ck_er_tipo CHECK ((tipo = ANY (ARRAY['P'::bpchar, 'I'::bpchar])))
);


ALTER TABLE public.entidad_rubros OWNER TO admin;

--
-- Name: TABLE entidad_rubros; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON TABLE public.entidad_rubros IS 'Relación entre entidades y sus productos/insumos clasificados';


--
-- Name: COLUMN entidad_rubros.codigo_entidad; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.entidad_rubros.codigo_entidad IS 'Referencia a entidades.codigo';


--
-- Name: COLUMN entidad_rubros.codigo_rubro; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.entidad_rubros.codigo_rubro IS 'Referencia a dic_rubros.codigo';


--
-- Name: COLUMN entidad_rubros.tipo; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.entidad_rubros.tipo IS 'P = Producto que ofrece  |  I = Insumo que consume';


--
-- Name: COLUMN entidad_rubros.observacion; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.entidad_rubros.observacion IS 'Detalle libre opcional (ej: variedad específica)';


--
-- Name: entidad_rubros_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.entidad_rubros_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.entidad_rubros_id_seq OWNER TO admin;

--
-- Name: entidad_rubros_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.entidad_rubros_id_seq OWNED BY public.entidad_rubros.id;


--
-- Name: hist_indicadores; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.hist_indicadores (
    id integer NOT NULL,
    fecha_corte date DEFAULT CURRENT_DATE NOT NULL,
    indicador character(5) NOT NULL,
    dimension character varying(30),
    valor_dim character varying(40),
    valor numeric(10,2) NOT NULL,
    total_entidades integer,
    observacion character varying(100)
);


ALTER TABLE public.hist_indicadores OWNER TO admin;

--
-- Name: TABLE hist_indicadores; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON TABLE public.hist_indicadores IS 'Snapshot mensual de todos los indicadores del sistema';


--
-- Name: hist_indicadores_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.hist_indicadores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hist_indicadores_id_seq OWNER TO admin;

--
-- Name: hist_indicadores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.hist_indicadores_id_seq OWNED BY public.hist_indicadores.id;


--
-- Name: historico_indicadores; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.historico_indicadores (
    id integer NOT NULL,
    fecha_corte date NOT NULL,
    indicador character varying(10) NOT NULL,
    sector character varying(60),
    municipio character varying(40),
    tamano character varying(20),
    valor numeric(8,2),
    valor_2 numeric(8,2),
    semaforo character varying(30),
    observacion character varying(200)
);


ALTER TABLE public.historico_indicadores OWNER TO admin;

--
-- Name: TABLE historico_indicadores; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON TABLE public.historico_indicadores IS 'Snapshots mensuales de los 6 indicadores';


--
-- Name: COLUMN historico_indicadores.fecha_corte; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.historico_indicadores.fecha_corte IS 'Fecha del snapshot, usar siempre el 1ro del mes';


--
-- Name: COLUMN historico_indicadores.valor_2; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.historico_indicadores.valor_2 IS 'Campo auxiliar: ratio, mínimo u otro valor secundario';


--
-- Name: historico_indicadores_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.historico_indicadores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.historico_indicadores_id_seq OWNER TO admin;

--
-- Name: historico_indicadores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.historico_indicadores_id_seq OWNED BY public.historico_indicadores.id;


--
-- Name: parroquias_carabobo; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.parroquias_carabobo (
    gid integer NOT NULL,
    parroquia character varying(40),
    municipio character varying(30),
    indice character varying(4),
    geom public.geometry(MultiPolygon,4326)
);


ALTER TABLE public.parroquias_carabobo OWNER TO admin;

--
-- Name: ref_geo; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ref_geo (
    codigo_parroquia character(4) NOT NULL,
    cod_municipio character(2) NOT NULL,
    municipio character varying(40) NOT NULL,
    parroquia character varying(40) NOT NULL
);


ALTER TABLE public.ref_geo OWNER TO admin;

--
-- Name: TABLE ref_geo; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON TABLE public.ref_geo IS 'Referencia geográfica municipios/parroquias Carabobo';


--
-- Name: COLUMN ref_geo.codigo_parroquia; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.ref_geo.codigo_parroquia IS 'Código compuesto 4 dígitos MMPP';


--
-- Name: COLUMN ref_geo.cod_municipio; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON COLUMN public.ref_geo.cod_municipio IS 'Primeros 2 dígitos = municipio';


--
-- Name: ref_sectores; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ref_sectores (
    codigo character varying(1) NOT NULL,
    nombre character varying(30) NOT NULL
);


ALTER TABLE public.ref_sectores OWNER TO admin;

--
-- Name: ref_tamanos; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ref_tamanos (
    codigo smallint NOT NULL,
    nombre character varying(20) NOT NULL
);


ALTER TABLE public.ref_tamanos OWNER TO admin;

--
-- Name: ref_tipos; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ref_tipos (
    codigo smallint NOT NULL,
    nombre character varying(20) NOT NULL
);


ALTER TABLE public.ref_tipos OWNER TO admin;

--
-- Name: users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users (
    id integer NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    email text NOT NULL,
    username text,
    password_hash text NOT NULL,
    last_login timestamp with time zone,
    role text DEFAULT 'user'::text NOT NULL,
    created timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.users OWNER TO admin;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO admin;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: v_encadenamientos_productivos; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.v_encadenamientos_productivos AS
 SELECT rp.categoria AS producto_ofrecido,
    ep.entidad AS entidad_productora,
    ep.municipio AS municipio_productor,
    ep.sector AS sector_productor,
    ri.categoria AS insumo_requerido,
    ec.entidad AS entidad_consumidora,
    ec.municipio AS municipio_consumidor,
    ec.sector AS sector_consumidor
   FROM (((((public.entidad_rubros erp
     JOIN public.dic_rubros rp ON (((rp.codigo = erp.codigo_rubro) AND (erp.tipo = 'P'::bpchar))))
     JOIN public.entidad ep ON ((ep.codigo = erp.codigo_entidad)))
     JOIN public.entidad_rubros erc ON (((erc.codigo_rubro = erp.codigo_rubro) AND (erc.tipo = 'I'::bpchar))))
     JOIN public.dic_rubros ri ON ((ri.codigo = erc.codigo_rubro)))
     JOIN public.entidad ec ON ((ec.codigo = erc.codigo_entidad)))
  WHERE (ep.codigo <> ec.codigo)
  ORDER BY rp.categoria, ep.municipio;


ALTER VIEW public.v_encadenamientos_productivos OWNER TO admin;

--
-- Name: v_iase; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.v_iase AS
 WITH anos AS (
         SELECT e.codigo,
            e.sector,
            e.tamano_entidad,
            e.municipio_parroquia,
            e.operativa,
            (EXTRACT(year FROM CURRENT_DATE) - EXTRACT(year FROM e.fecha_inicio)) AS anos_actividad
           FROM public.entidad e
          WHERE (e.fecha_inicio IS NOT NULL)
        )
 SELECT s.nombre AS sector,
    g.municipio,
    t.nombre AS tamano,
    count(a.codigo) AS total_entidades,
    round(avg(a.anos_actividad), 1) AS antiguedad_promedio,
        CASE
            WHEN (round(avg(a.anos_actividad), 1) <= (2)::numeric) THEN 'Emergente'::text
            WHEN (round(avg(a.anos_actividad), 1) <= (5)::numeric) THEN 'En consolidación'::text
            WHEN (round(avg(a.anos_actividad), 1) <= (10)::numeric) THEN 'Establecida'::text
            WHEN (round(avg(a.anos_actividad), 1) <= (20)::numeric) THEN 'Madura'::text
            ELSE 'Ancla territorial'::text
        END AS clasificacion,
    count(*) FILTER (WHERE (a.anos_actividad <= (2)::numeric)) AS cnt_emergente,
    count(*) FILTER (WHERE ((a.anos_actividad >= (3)::numeric) AND (a.anos_actividad <= (5)::numeric))) AS cnt_consolidacion,
    count(*) FILTER (WHERE ((a.anos_actividad >= (6)::numeric) AND (a.anos_actividad <= (10)::numeric))) AS cnt_establecida,
    count(*) FILTER (WHERE ((a.anos_actividad >= (11)::numeric) AND (a.anos_actividad <= (20)::numeric))) AS cnt_madura,
    count(*) FILTER (WHERE (a.anos_actividad > (20)::numeric)) AS cnt_ancla,
    round(avg(a.operativa), 1) AS operativa_promedio
   FROM (((anos a
     JOIN public.ref_sectores s ON (((s.codigo)::text = (a.sector)::text)))
     JOIN public.ref_tamanos t ON ((t.codigo = a.tamano_entidad)))
     JOIN public.ref_geo g ON (((g.codigo_parroquia)::text = lpad((a.municipio_parroquia)::text, 4, '0'::text))))
  GROUP BY s.nombre, g.municipio, t.nombre
  ORDER BY g.municipio, (round(avg(a.anos_actividad), 1)) DESC;


ALTER VIEW public.v_iase OWNER TO admin;

--
-- Name: VIEW v_iase; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON VIEW public.v_iase IS 'IASE — Índice de Antigüedad y Supervivencia Empresarial

Mide estabilidad del tejido empresarial por tramos de edad

Campo clave: fecha_inicio';


--
-- Name: v_idchs; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.v_idchs AS
 SELECT s.nombre AS sector,
    g.municipio,
    t.nombre AS tamano,
    count(e.codigo) AS total_entidades,
    sum(e.capital_humano) AS total_empleos,
    round(avg(e.capital_humano), 1) AS promedio_empleos,
    min(e.capital_humano) AS minimo_empleos,
    max(e.capital_humano) AS maximo_empleos,
    round((((sum(e.capital_humano))::numeric * 100.0) / NULLIF(sum(sum(e.capital_humano)) OVER (PARTITION BY g.municipio), (0)::numeric)), 1) AS peso_empleo_municipio_pct
   FROM (((public.entidad e
     JOIN public.ref_sectores s ON (((s.codigo)::text = (e.sector)::text)))
     JOIN public.ref_tamanos t ON ((t.codigo = e.tamano_entidad)))
     JOIN public.ref_geo g ON (((g.codigo_parroquia)::text = lpad((e.municipio_parroquia)::text, 4, '0'::text))))
  WHERE (e.capital_humano IS NOT NULL)
  GROUP BY s.nombre, g.municipio, t.nombre
  ORDER BY g.municipio, (sum(e.capital_humano)) DESC;


ALTER VIEW public.v_idchs OWNER TO admin;

--
-- Name: VIEW v_idchs; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON VIEW public.v_idchs IS 'IDCHS — Índice de Densidad de Capital Humano por Sector

Mide concentración de empleos por sector y tamaño

Campos: capital_humano, sector, tamano_entidad';


--
-- Name: v_idpdi; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.v_idpdi AS
 WITH conteos AS (
         SELECT e.codigo,
            e.sector,
            e.tamano_entidad,
            e.municipio_parroquia,
                CASE
                    WHEN ((e.productos IS NOT NULL) AND ((e.productos)::text <> ''::text)) THEN ((length((e.productos)::text) - length(replace((e.productos)::text, ','::text, ''::text))) + 1)
                    ELSE 0
                END AS n_productos,
                CASE
                    WHEN ((e.materia_prima IS NOT NULL) AND ((e.materia_prima)::text <> ''::text)) THEN ((length((e.materia_prima)::text) - length(replace((e.materia_prima)::text, ','::text, ''::text))) + 1)
                    ELSE 0
                END AS n_insumos
           FROM public.entidad e
          WHERE ((e.productos IS NOT NULL) AND (e.materia_prima IS NOT NULL))
        )
 SELECT s.nombre AS sector,
    g.municipio,
    t.nombre AS tamano,
    count(c.codigo) AS total_entidades,
    round(avg(c.n_productos), 1) AS promedio_productos,
    round(avg(c.n_insumos), 1) AS promedio_insumos,
    round(avg(((c.n_productos)::numeric / (NULLIF(c.n_insumos, 0))::numeric)), 2) AS ratio_idpdi,
        CASE
            WHEN (round(avg(((c.n_productos)::numeric / (NULLIF(c.n_insumos, 0))::numeric)), 2) >= (2)::numeric) THEN 'Alta diversificación'::text
            WHEN (round(avg(((c.n_productos)::numeric / (NULLIF(c.n_insumos, 0))::numeric)), 2) >= (1)::numeric) THEN 'Equilibrado'::text
            ELSE 'Alta dependencia de insumos'::text
        END AS clasificacion
   FROM (((conteos c
     JOIN public.ref_sectores s ON (((s.codigo)::text = (c.sector)::text)))
     JOIN public.ref_tamanos t ON ((t.codigo = c.tamano_entidad)))
     JOIN public.ref_geo g ON (((g.codigo_parroquia)::text = lpad((c.municipio_parroquia)::text, 4, '0'::text))))
  GROUP BY s.nombre, g.municipio, t.nombre
  ORDER BY (round(avg(((c.n_productos)::numeric / (NULLIF(c.n_insumos, 0))::numeric)), 2)) DESC;


ALTER VIEW public.v_idpdi OWNER TO admin;

--
-- Name: VIEW v_idpdi; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON VIEW public.v_idpdi IS 'IDPDI — Índice de Diversificación Productiva y Dependencia de Insumos

Conteo de ítems en productos y materia_prima (separados por coma)

Campos: productos, materia_prima';


--
-- Name: v_ieet; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.v_ieet AS
 WITH base AS (
         SELECT g.municipio,
            s.nombre AS sector,
            count(e.codigo) AS entidades_sector
           FROM ((public.entidad e
             JOIN public.ref_sectores s ON (((s.codigo)::text = (e.sector)::text)))
             JOIN public.ref_geo g ON (((g.codigo_parroquia)::text = lpad((e.municipio_parroquia)::text, 4, '0'::text))))
          GROUP BY g.municipio, s.nombre
        ), totales AS (
         SELECT base.municipio,
            sum(base.entidades_sector) AS total_municipio
           FROM base
          GROUP BY base.municipio
        )
 SELECT b.municipio,
    b.sector,
    b.entidades_sector,
    t.total_municipio,
    round((((b.entidades_sector)::numeric * 100.0) / NULLIF(t.total_municipio, (0)::numeric)), 1) AS peso_pct,
        CASE
            WHEN (round((((b.entidades_sector)::numeric * 100.0) / NULLIF(t.total_municipio, (0)::numeric)), 1) >= (60)::numeric) THEN 'Sector dominante'::text
            WHEN (round((((b.entidades_sector)::numeric * 100.0) / NULLIF(t.total_municipio, (0)::numeric)), 1) >= (30)::numeric) THEN 'Sector relevante'::text
            ELSE 'Sector secundario'::text
        END AS rol_sector
   FROM (base b
     JOIN totales t ON (((t.municipio)::text = (b.municipio)::text)))
  ORDER BY b.municipio, (round((((b.entidades_sector)::numeric * 100.0) / NULLIF(t.total_municipio, (0)::numeric)), 1)) DESC;


ALTER VIEW public.v_ieet OWNER TO admin;

--
-- Name: VIEW v_ieet; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON VIEW public.v_ieet IS 'IEET — Índice de Estructura Económica Territorial

Mide diversificación sectorial por municipio

Campos: sector, municipio_parroquia';


--
-- Name: v_inos; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.v_inos AS
 SELECT s.nombre AS sector,
    g.municipio,
    count(e.codigo) AS total_entidades,
    round(avg(e.operativa), 1) AS inos,
    min(e.operativa) AS minimo,
    max(e.operativa) AS maximo,
    count(*) FILTER (WHERE (e.operativa >= 80)) AS cnt_optimo,
    count(*) FILTER (WHERE ((e.operativa >= 60) AND (e.operativa < 80))) AS cnt_aceptable,
    count(*) FILTER (WHERE ((e.operativa >= 40) AND (e.operativa < 60))) AS cnt_bajo,
    count(*) FILTER (WHERE (e.operativa < 40)) AS cnt_critico,
        CASE
            WHEN (round(avg(e.operativa), 1) >= (80)::numeric) THEN 'Óptimo'::text
            WHEN (round(avg(e.operativa), 1) >= (60)::numeric) THEN 'Aceptable'::text
            WHEN (round(avg(e.operativa), 1) >= (40)::numeric) THEN 'Bajo'::text
            ELSE 'Crítico'::text
        END AS semaforo
   FROM ((public.entidad e
     JOIN public.ref_sectores s ON (((s.codigo)::text = (e.sector)::text)))
     JOIN public.ref_geo g ON (((g.codigo_parroquia)::text = lpad((e.municipio_parroquia)::text, 4, '0'::text))))
  WHERE (e.operativa IS NOT NULL)
  GROUP BY s.nombre, g.municipio
  ORDER BY (round(avg(e.operativa), 1)) DESC;


ALTER VIEW public.v_inos OWNER TO admin;

--
-- Name: VIEW v_inos; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON VIEW public.v_inos IS 'INOS — Índice de Nivel Operativo Sectorial

Mide el % promedio de operatividad real por sector/municipio

Campo clave: operativa (entero 0-100)';


--
-- Name: v_ipdm; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.v_ipdm AS
 WITH digital AS (
         SELECT e.codigo,
            e.sector,
            e.municipio_parroquia,
            (((
                CASE
                    WHEN ((e.web_entidad IS NOT NULL) AND ((e.web_entidad)::text <> ''::text)) THEN 1
                    ELSE 0
                END +
                CASE
                    WHEN ((e.instagram_entidad IS NOT NULL) AND ((e.instagram_entidad)::text <> ''::text)) THEN 1
                    ELSE 0
                END) +
                CASE
                    WHEN ((e.twitter_entidad IS NOT NULL) AND ((e.twitter_entidad)::text <> ''::text)) THEN 1
                    ELSE 0
                END) +
                CASE
                    WHEN ((e.facebook_entidad IS NOT NULL) AND ((e.facebook_entidad)::text <> ''::text)) THEN 1
                    ELSE 0
                END) AS canales,
            e.participacion_mercado
           FROM public.entidad e
        )
 SELECT s.nombre AS sector,
    g.municipio,
    count(d.codigo) AS total_entidades,
    round(avg(d.canales), 2) AS promedio_canales_digitales,
    round(avg(d.participacion_mercado), 1) AS promedio_mercado,
    round(avg(((((d.canales)::numeric / 4.0) * (40)::numeric) + ((d.participacion_mercado)::numeric * 0.60))), 1) AS ipdm,
        CASE
            WHEN (round(avg(((((d.canales)::numeric / 4.0) * (40)::numeric) + ((d.participacion_mercado)::numeric * 0.60))), 1) >= (70)::numeric) THEN 'Alto'::text
            WHEN (round(avg(((((d.canales)::numeric / 4.0) * (40)::numeric) + ((d.participacion_mercado)::numeric * 0.60))), 1) >= (40)::numeric) THEN 'Medio'::text
            ELSE 'Bajo'::text
        END AS nivel
   FROM ((digital d
     JOIN public.ref_sectores s ON (((s.codigo)::text = (d.sector)::text)))
     JOIN public.ref_geo g ON (((g.codigo_parroquia)::text = lpad((d.municipio_parroquia)::text, 4, '0'::text))))
  GROUP BY s.nombre, g.municipio
  ORDER BY (round(avg(((((d.canales)::numeric / 4.0) * (40)::numeric) + ((d.participacion_mercado)::numeric * 0.60))), 1)) DESC;


ALTER VIEW public.v_ipdm OWNER TO admin;

--
-- Name: VIEW v_ipdm; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON VIEW public.v_ipdm IS 'IPDM — Índice de Penetración Digital y Presencia de Mercado
Mide visibilidad digital + participación de mercado
Campos: web_entidad, instagram_entidad, twitter_entidad,facebook_entidad (correo), participacion_mercado';


--
-- Name: entidad_rubros id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.entidad_rubros ALTER COLUMN id SET DEFAULT nextval('public.entidad_rubros_id_seq'::regclass);


--
-- Name: hist_indicadores id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.hist_indicadores ALTER COLUMN id SET DEFAULT nextval('public.hist_indicadores_id_seq'::regclass);


--
-- Name: historico_indicadores id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.historico_indicadores ALTER COLUMN id SET DEFAULT nextval('public.historico_indicadores_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alcaldiainfraestructura; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/5202.dat

--
-- Data for Name: dic_rubros; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/5206.dat

--
-- Data for Name: entidad; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/5205.dat

--
-- Data for Name: entidad_rubros; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/5208.dat

--
-- Data for Name: hist_indicadores; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/5212.dat

--
-- Data for Name: historico_indicadores; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/5216.dat

--
-- Data for Name: parroquias_carabobo; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/5203.dat

--
-- Data for Name: ref_geo; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/5214.dat

--
-- Data for Name: ref_sectores; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/5210.dat

--
-- Data for Name: ref_tamanos; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/5213.dat

--
-- Data for Name: ref_tipos; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/5209.dat

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/4973.dat

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/5200.dat

--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: admin
--

\i $$PATH$$/4975.dat

--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: admin
--

\i $$PATH$$/4976.dat

--
-- Name: alcaldiainfraestructura_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.alcaldiainfraestructura_id_seq', 719, true);


--
-- Name: entidad_codigo_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.entidad_codigo_seq', 380, true);


--
-- Name: entidad_rubros_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.entidad_rubros_id_seq', 1, false);


--
-- Name: hist_indicadores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.hist_indicadores_id_seq', 1, false);


--
-- Name: historico_indicadores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.historico_indicadores_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: admin
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- Name: alcaldiainfraestructura alcaldiainfraestructura_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alcaldiainfraestructura
    ADD CONSTRAINT alcaldiainfraestructura_pkey PRIMARY KEY (id);


--
-- Name: entidad entidad_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.entidad
    ADD CONSTRAINT entidad_pkey PRIMARY KEY (codigo);


--
-- Name: dic_rubros pk_dic_rubros; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.dic_rubros
    ADD CONSTRAINT pk_dic_rubros PRIMARY KEY (codigo);


--
-- Name: entidad_rubros pk_entidad_rubros; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.entidad_rubros
    ADD CONSTRAINT pk_entidad_rubros PRIMARY KEY (id);


--
-- Name: hist_indicadores pk_hist_indicadores; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.hist_indicadores
    ADD CONSTRAINT pk_hist_indicadores PRIMARY KEY (id);


--
-- Name: historico_indicadores pk_historico; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.historico_indicadores
    ADD CONSTRAINT pk_historico PRIMARY KEY (id);


--
-- Name: ref_geo pk_ref_geo; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ref_geo
    ADD CONSTRAINT pk_ref_geo PRIMARY KEY (codigo_parroquia);


--
-- Name: ref_sectores pk_ref_sectores; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ref_sectores
    ADD CONSTRAINT pk_ref_sectores PRIMARY KEY (codigo);


--
-- Name: ref_tamanos pk_ref_tamanos; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ref_tamanos
    ADD CONSTRAINT pk_ref_tamanos PRIMARY KEY (codigo);


--
-- Name: ref_tipos pk_ref_tipos; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ref_tipos
    ADD CONSTRAINT pk_ref_tipos PRIMARY KEY (codigo);


--
-- Name: entidad_rubros uq_entidad_rubro_tipo; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.entidad_rubros
    ADD CONSTRAINT uq_entidad_rubro_tipo UNIQUE (codigo_entidad, codigo_rubro, tipo);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_alcaldia_area; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_alcaldia_area ON public.alcaldiainfraestructura USING btree (alcaldia, areadato);


--
-- Name: idx_er_entidad; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_er_entidad ON public.entidad_rubros USING btree (codigo_entidad);


--
-- Name: idx_er_rubro; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_er_rubro ON public.entidad_rubros USING btree (codigo_rubro);


--
-- Name: idx_er_tipo; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_er_tipo ON public.entidad_rubros USING btree (tipo);


--
-- Name: idx_fecha_ingreso; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_fecha_ingreso ON public.alcaldiainfraestructura USING btree (fechaingreso);


--
-- Name: idx_hist_fecha; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_hist_fecha ON public.hist_indicadores USING btree (fecha_corte);


--
-- Name: idx_hist_indicador; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_hist_indicador ON public.hist_indicadores USING btree (indicador);


--
-- Name: idx_hist_municipio; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_hist_municipio ON public.historico_indicadores USING btree (municipio);


--
-- Name: parroquias_carabobo_gid_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX parroquias_carabobo_gid_idx ON public.parroquias_carabobo USING btree (gid);


--
-- Name: entidad_rubros fk_er_entidad; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.entidad_rubros
    ADD CONSTRAINT fk_er_entidad FOREIGN KEY (codigo_entidad) REFERENCES public.entidad(codigo) ON DELETE CASCADE;


--
-- Name: entidad_rubros fk_er_rubro; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.entidad_rubros
    ADD CONSTRAINT fk_er_rubro FOREIGN KEY (codigo_rubro) REFERENCES public.dic_rubros(codigo);


--
-- PostgreSQL database dump complete
--

